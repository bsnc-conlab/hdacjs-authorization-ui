import React from 'react';
import '../effect/App.css';
import Header from './Header.js';
import KeyList from './KeyList.js';
import InNOut from './InNOut.js';

class App extends React.Component {
  render(){
      return  (
          <div>
              <Header/>
              <KeyList/>
              <InNOut/>
          </div>
      );
  }
}
export default App;
