import React, { Component } from 'react';
import Tabs from '../tab_lib/Tabs.js'
import TabContent from '../tab_lib/TabContent.js'
import TabLink from '../tab_lib/TabLink.js'

import '../effect/styles.css';

const styles = {
  tabs: {
    width: '100%',
    display: 'inline-block',
    marginRight: '30px',
    verticalAlign: 'top',
  },
  links: {
    margin: 0,
    padding: 0,
  },
  tabLink: {
    height: '30px',
    lineHeight: '30px',
    padding: '0 15px',
    cursor: 'pointer',
    border: 'none',
    borderBottom: '2px solid transparent',
    display: 'inline-block',
  },
  activeLinkStyle: {
    borderBottom: '2px solid #333',
  },
  visibleTabStyle: {
    display: 'inline-block',
  },
  content: {
    width: '100%',
    padding: '0 15px',
  },
};

export default class InNOut extends React.Component {
  render(){
    return (
      <Tabs
      activeLinkStyle={styles.activeLinkStyle}
      visibleTabStyle={styles.visibleTabStyle}
      style={styles.tabs}
    >
      <div style={styles.links}>
        <TabLink to="tab1" style={styles.tabLink}>
          SIGN
        </TabLink>
        <TabLink to="tab2" style={styles.tabLink}>
          VERIFY
        </TabLink>
        <TabLink to="tab3" style={styles.tabLink}>
          RSA ENCRYPT
        </TabLink>
        <TabLink to="tab4" style={styles.tabLink}>
          RSA DECRYPT
        </TabLink>
        <TabLink to="tab5" style={styles.tabLink}>
          EFFECT ENCRYPT
        </TabLink>
        <TabLink to="tab6" style={styles.tabLink}>
          EFFECT DECRYPT
        </TabLink>
      </div>

      <div id="tab_content" style={styles.content}>
        <TabContent for="tab1">
          <div id="sign">
            <div id="space"><div><br></br></div></div>
            <div id="sign_in1">
              <h1>Input</h1>
              <table id="input">
                <tr id="input"><td id="input"><input id="input_1" type="text" placeholder="message"></input></td></tr>
                <tr id="input"><td id="input"><input id="input_2" type="text" placeholder="private key"></input></td></tr>
                <tr id="input"><td id="input"><input id="input_3" type="text" placeholder="password"></input></td></tr>
              </table>
            </div>
            <div id="semi-space"><div><br></br></div></div>
            <div id="sign_in2">
              <h1>Output</h1>
              <table id="output">
                <tr id="output"><td id="output" colSpan="3"><textarea id="output_text" readOnly="readonly" placeholder="result"></textarea></td></tr>
                <tr id="output"><td id="output_btn"><button id="sign_btn">SIGN</button></td></tr>
              </table>
            </div>
            <div id="space"><div><br></br></div></div>
          </div>
        </TabContent>
        <TabContent for="tab2">
        <div id="sign">
          <div id="space"><div><br></br></div></div>
          <div id="verify_in1">
            <h1>Input</h1>
            <table id="input">
                <tr id="input"><td id="input"><input id="input_1" type="text" placeholder="message"></input></td></tr>
                <tr id="input"><td id="input"><input id="input_2" type="text" placeholder="address"></input></td></tr>
                <tr id="input"><td id="input"><input id="input_3" type="text" placeholder="signed message"></input></td></tr>
              </table>
            </div>
            <div id="semi-space"><div><br></br></div></div>
            <div id="sign_in2">
              <h1>Output</h1>
              <table id="output">
                <tr id="output"><td id="output" colSpan="3"><textarea id="output_text" readOnly="readonly" placeholder="result"></textarea></td></tr>
                <tr id="output"><td id="output_btn"><button id="verify_btn">VERIFY</button></td></tr>
              </table>
          </div>
          <div id="space"><div><br></br></div></div>
        </div>
        </TabContent>
        <TabContent for="tab3">
        <div id="sign">
          <div id="space"><div><br></br></div></div>
          <div id="rsa_in1">
            <h1>Input</h1>
            <table id="input">
                <tr id="input"><td id="input"><input id="input_1" type="text" placeholder="message"></input></td></tr>
                <tr id="input"><td id="input"><input id="input_2" type="text" placeholder="uncompresses pubkey"></input></td></tr>
              </table>
            </div>
            <div id="semi-space"><div><br></br></div></div>
            <div id="sign_in2">
              <h1>Output</h1>
              <table id="output">
                <tr id="output"><td id="output" colSpan="3"><textarea id="output_text" readOnly="readonly" placeholder="result"></textarea></td></tr>
                <tr id="output"><td id="output_btn"><button id="encrypt_btn">RSA ENCRYPT</button></td></tr>
              </table>
          </div>
          <div id="space"><div><br></br></div></div>
        </div>
        </TabContent>
        <TabContent for="tab4">
        <div id="sign">
          <div id="space"><div><br></br></div></div>
          <div id="rsa_in1">
            <h1>Input</h1>
            <table id="input">
                <tr id="input"><td id="input"><input id="input_1" type="text" placeholder="privatekey"></input></td></tr>
                <tr id="input"><td id="input"><input id="input_2" type="text" placeholder="rsa encypted message"></input></td></tr>
              </table>
            </div>
            <div id="semi-space"><div><br></br></div></div>
            <div id="sign_in2">
              <h1>Output</h1>
              <table id="output">
                <tr id="output"><td id="output" colSpan="3"><textarea id="output_text" readOnly="readonly" placeholder="result"></textarea></td></tr>
                <tr id="output"><td id="output_btn"><button id="decrypt_btn">RSA DECRYPT</button></td></tr>
              </table>
          </div>
          <div id="space"><div><br></br></div></div>
        </div>
        </TabContent>
        <TabContent for="tab5">
        <div id="sign">
          <div id="space"><div><br></br></div></div>
          <div id="effect_in1">
            <h1>Input</h1>
            <table id="input">
                <tr id="input"><td id="input"><input id="input_1" type="text" placeholder="message"></input></td></tr>
                <tr id="input"><td id="input"><input id="input_2" type="text" placeholder="Address"></input></td></tr>
              </table>
            </div>
            <div id="semi-space"><div><br></br></div></div>
            <div id="sign_in2">
              <h1>Output</h1>
              <table id="output">
                <tr id="output"><td id="output" colSpan="3"><textarea id="output_text" readOnly="readonly" placeholder="result"></textarea></td></tr>
                <tr id="output"><td id="output_btn"><button id="encrypt_btn">EFFECT ENCRYPT</button></td></tr>
              </table>
          </div>
          <div id="space"><div><br></br></div></div>
        </div>
        </TabContent>
        <TabContent for="tab6">
        <div id="sign">
          <div id="space"><div><br></br></div></div>
          <div id="effect_in1">
            <h1>Input</h1>
            <table id="input">
                <tr id="input"><td id="input"><input id="input_1" type="text" placeholder="private key"></input></td></tr>
                <tr id="input"><td id="input"><input id="input_2" type="text" placeholder="effect encrypted message"></input></td></tr>
              </table>
            </div>
            <div id="semi-space"><div><br></br></div></div>
            <div id="sign_in2">
              <h1>Output</h1>
              <table id="output">
                <tr id="output"><td id="output" colSpan="3"><textarea id="output_text" readOnly="readonly" placeholder="result"></textarea></td></tr>
                <tr id="output"><td id="output_btn"><button id="decrypt_btn">EFFECT DECRYPT</button></td></tr>
              </table>
          </div>
          <div id="space"><div><br></br></div></div>
        </div>
        </TabContent>
      </div>
    </Tabs>
    );
}
}