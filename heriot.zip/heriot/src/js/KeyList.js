import React, { Component } from 'react';
import ReactDataGrid from "react-data-grid";
import createRowData from "./createRowData.js";
// import columns from './grid.js';

const COLUMN_WIDTH = 340;
const columns = [{name: "select",frozen: true,width: 70},{key: "no",name: "NO.",frozen: true,width: 45},{key: "address",name: "Address",frozen: true,width: COLUMN_WIDTH},{key: "uncompressed",name: "Uncompressed Pubkey",frozen: true,width: COLUMN_WIDTH},{key: "compressed",name: "Compresses Pubkey",frozen: true,width: COLUMN_WIDTH},{key: "privateKey",name: "Private Key",frozen: true,width: COLUMN_WIDTH},{key: "isEncrypted",name: "Is Encrypted",frozen: true,width: COLUMN_WIDTH},{key: "del",name: "Del",frozen: true,width: 50}];
const ROW_COUNT = 1;  //TODO - count
const rows = createRowData(1); //TODO - data

export default class KeyList extends React.Component {
    
  render(){
        return (
          <div id="keyList">
            <ReactDataGrid
              columns={columns}
              rowGetter={i => rows[i]}
              rowsCount={ROW_COUNT}
              minHeight={300}
              minWidth={1898}
            />
          </div>
        );
    }
}