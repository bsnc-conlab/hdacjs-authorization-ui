import React, { Component } from 'react';
import Modal from 'react-awesome-modal';
import logo from '../img/logo.png';
import * as hdac from 'hdacjs-lib';
//import createKeypairs from './lib/hdacjs.js';

export default class Header extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
          fadeInDown : false
      }
    }
    
    open(effect) {
      this.setState({
        [effect] : true
      });
    }
  
    close(effect) {
      this.setState({
        [effect] : false
      });
    }
    ckpTest() {
      // console.log(${hdac.createKeypairs("2345")});
      console.log(hdac);
      // console.log(hdac.createKeypairs("dd"));
      // console.log(createKeypairs);d
      // console.log(hdac.aesEncrypt("111","hello"));
    }

    render(){
        return (
          <div id="header">
            <div id="logo"><a href="javascript:location.reload()"><img src={logo}/></a></div>
            <div id="head-title"><a>HdacJs Test UI</a></div>
            <div id="head-btn"><button id="btn" onClick={() => this.open('fadeInDown')}>create key pairs</button>
            <Modal visible={this.state.fadeInDown} effect="fadeInDown" onClickAway={() => this.close('fadeInDown')} width="450" height="500">
              <div className="Modal">
                  <div id="modal_content"><table id="tb_content">
                    <tr>
                      <th>:: PASSWORD ::<br></br><br></br>
                      <input type="password" id="pwd"></input><br></br>
                      <a id="warning">warning) If you create without password,<br></br>This program will display the unencrypted private key.</a>
                      </th>
                    </tr>
                  </table></div>
                  <div>
                    <table id="tb_btn"><tr><th><button id="modal_btn" onClick={() => this.close('fadeInDown')}>Cancel</button></th><th><button onclick={() => this.ckpTest()} id="modal_btn">Create</button></th></tr></table>
                  </div>
              </div>
            </Modal>
          </div>
          </div>
        );
    }
} 