const COLUMN_WIDTH = 340;
const columns = [
  {
    name: "select",
    frozen: true,
    width: 70
  },
  {
    key: "no",
    name: "NO.",
    frozen: true,
    width: 45
  },
  {
    key: "address",
    name: "Address",
    frozen: true,
    width: COLUMN_WIDTH
  },
  {
    key: "uncompressed",
    name: "Uncompressed Pubkey",
    frozen: true,
    width: COLUMN_WIDTH
  },
  {
    key: "compressed",
    name: "Compresses Pubkey",
    frozen: true,
    width: COLUMN_WIDTH
  },
  {
    key: "privateKey",
    name: "Private Key",
    frozen: true,
    width: COLUMN_WIDTH
  },
  {
    key: "isEncrypted",
    name: "Is Encrypted",
    frozen: true,
    width: COLUMN_WIDTH
  },
  {
    key: "del",
    name: "Delete",
    frozen: true,
    width: 50
  }
];