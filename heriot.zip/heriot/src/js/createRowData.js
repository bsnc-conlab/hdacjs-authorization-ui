import faker from "faker";


function createFakeRow(index) {
  return {
    no: index,
    address: faker.name.lastName(),
    uncompressed: faker.name.lastName(),
    compressed: faker.name.lastName(),
    privateKey: faker.name.lastName(),
    isEncrypted: faker.name.lastName(),
    del: faker.name.lastName()
  };
}

export default function createRowData(count) {
  return [...Array(count).keys()].map(i => createFakeRow(i));
}
