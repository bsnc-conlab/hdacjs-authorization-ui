import fadeInDown from './effect/fadeInDown';

export default {
    fadeInDown : fadeInDown
};
